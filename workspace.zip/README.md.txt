# vMix RTSP Toolkit

**Herramienta open source** para streamers y productores que usan **vMix** (principal) y **OBS Studio** (secundario).

## Características principales
- RTSP Server optimizado para vMix
- 2 salidas RTMP simultáneas
- Soporte **SRT** (baja latencia)
- Soporte **NDI**
- Latencia configurable (Ultra Low, Low, Medium)
- Interfaz gráfica ligera (Tauri)

## Requisitos
- Windows 10/11
- ffmpeg (debe estar en el PATH)
- NDI Tools (recomendado)

## Cómo usar
1. Ejecuta la app
2. Configura el puerto RTSP
3. Inicia el servidor
4. Agrega la URL en vMix como "Stream Input"

## Licencia
MIT License - Libre para usar y modificar.

---

Creado para la comunidad de streamers.